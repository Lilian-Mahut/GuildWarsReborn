# Guild Wars 1 - Carte interactive (Elona + Cantha)

## Mise en route (nouveau PC)

1. **Leaflet en local** : télécharger Leaflet 1.9.x sur https://leafletjs.com/download.html,
   puis copier le contenu du dossier `dist/` (leaflet.js, leaflet.css, dossier images/)
   dans `vendor/leaflet/`.
2. **Tuiles** : placer la pyramide de tuiles de la carte fusionnée dans
   `images/world/{z}/{x}/{y}.jpg` (zoom 0 à 4).
   Adapter `tilesAtZoom0` dans `data/world.json` = [colonnes, lignes] de tuiles 256px au zoom 0.
3. **Lancer** : dans VS Code, installer l'extension "Live Server", clic droit sur
   `index.html` > "Open with Live Server" (le chargement des JSON exige un serveur).

## Où modifier quoi

| Je veux...                               | Fichier                                   |
|------------------------------------------|-------------------------------------------|
| Changer à quel zoom apparaît une catégorie | `data/layers.json`                       |
| Changer la taille des icônes selon le zoom | `data/layers.json` (iconScales)          |
| Ajouter / déplacer un lieu               | `data/realms/<royaume>/<categorie>.json`  |
| Changer une icône                        | `assets/realms/<royaume>/icons/`          |
| Changer la police / couleurs d'un royaume | `css/realms/<royaume>.css`                |
| Ajouter un royaume                       | voir ci-dessous                           |

## Ajouter un royaume

1. Créer `data/realms/<id>/` avec `realm.json` + un JSON par catégorie.
2. Créer `assets/realms/<id>/icons/` et `fonts/`.
3. Créer `css/realms/<id>.css`.
4. Ajouter `"<id>"` dans la liste `realms` de `data/world.json`.

## Options par lieu (facultatives)

`minZoom`, `labelMinZoom`, `"label": false` (ne jamais afficher le nom).

## Relever des coordonnées

Cliquer sur la carte : la console du navigateur (F12) affiche `{ "x": ..., "y": ... }`
au zoom maximum, à copier dans le JSON.

## Remarques

- Les coordonnées fournies sont des EXEMPLES fictifs, à remplacer.
- Les icônes fournies sont des cercles de remplacement, à remplacer par les vraies.
- Pas de virgule après le dernier élément d'un tableau JSON.
